import React, { useEffect } from "react";

declare global {
  interface Window {
    paypal?: any;
  }
}

interface PayPalSubscriptionButtonProps {
  userId: number;
}

export const PayPalSubscriptionButton: React.FC<
  PayPalSubscriptionButtonProps
> = ({ userId }) => {
  useEffect(() => {
    const containerId = "paypal-button-container-P-3TV56568CV310331FNEVVGCI";

    const renderButtons = () => {
      if (!window.paypal) return;
      window.paypal
        .Buttons({
          style: {
            shape: "rect",
            color: "gold",
            layout: "vertical",
            label: "subscribe",
          },
          createSubscription: (data: any, actions: any) => {
            return actions.subscription.create({
              plan_id: "P-3TV56568CV310331FNEVVGCI",
              custom_id: String(userId),
            });
          },
          onApprove: (data: any) => {
            // You can replace this with a nicer in-app toast if desired.
            // This matches the provided snippet behavior.
            // eslint-disable-next-line no-alert
            alert(data.subscriptionID);
          },
        })
        .render(`#${containerId}`);
    };

    if (window.paypal) {
      renderButtons();
      return;
    }

    const scriptId = "paypal-sdk-subscription-script";
    if (document.getElementById(scriptId)) {
      const interval = setInterval(() => {
        if (window.paypal) {
          clearInterval(interval);
          renderButtons();
        }
      }, 150);
      return () => clearInterval(interval);
    }

    const script = document.createElement("script");
    script.id = scriptId;
    script.src =
      "https://www.paypal.com/sdk/js?client-id=AT3xHQf0ffP919RYZ9lbkvG7yvmXWxEr74e4nFDIwHf9a-kpWM7zrvTZR7EFKBZpQvI3HpI-on8v0L-j&vault=true&intent=subscription";
    script.setAttribute("data-sdk-integration-source", "button-factory");
    script.onload = renderButtons;
    document.body.appendChild(script);
  }, [userId]);

  return (
    <div
      id="paypal-button-container-P-3TV56568CV310331FNEVVGCI"
      className="mt-2"
    />
  );
};

