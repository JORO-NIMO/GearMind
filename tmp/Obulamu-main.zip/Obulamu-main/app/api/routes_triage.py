from __future__ import annotations

from fastapi import APIRouter, Depends

from app.schemas import TriageRequest, TriageResponse, TriageResultSchema
from app.services.triage_service import TriageService, get_triage_service

router = APIRouter(prefix="/triage", tags=["triage"])


@router.post("/", response_model=TriageResponse)
def triage_text_endpoint(
    payload: TriageRequest,
    triage_service: TriageService = Depends(get_triage_service),
) -> TriageResultSchema:
    result = triage_service.triage(payload.text)
    return TriageResultSchema(
        category=result.category,
        red_flags=result.red_flags,
        advice=result.advice,
        recommended_action=result.recommended_action,
        recommended_setting=result.recommended_setting,
        use_premium_model=result.use_premium_model,
    )
