from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class TriageResult:
    category: str
    red_flags: list[str]
    advice: str
    recommended_action: str
    recommended_setting: str
    use_premium_model: bool


EMERGENCY_KEYWORDS = [
    "chest pain",
    "severe chest pain",
    "shortness of breath",
    "difficulty breathing",
    "not breathing",
    "blue lips",
    "unconscious",
    "seizure",
    "severe bleeding",
    "cannot wake",
    "stroke",
    "weakness on one side",
    "slurred speech",
    "confusion",
    "sudden weakness",
    "sudden severe headache",
    "loss of consciousness",
    "severe allergic reaction",
    "swelling of tongue",
    "swelling of throat",
]

URGENT_KEYWORDS = [
    "high fever",
    "fever for more than",
    "severe pain",
    "pregnant and bleeding",
    "sudden vision loss",
    "moderate chest discomfort",
    "severe headache",
    "worsening shortness of breath",
    "blood in stool",
    "blood in vomit",
    "severe abdominal pain",
    "painful urination with fever",
]


def detect_keywords(text: str, keywords: List[str]) -> list[str]:
    lowered = text.lower()
    hits: list[str] = []
    for k in keywords:
        if k in lowered:
            hits.append(k)
    return hits
