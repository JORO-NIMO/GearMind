from __future__ import annotations

from typing import Literal, Tuple

from openai import OpenAI

from config.settings import get_settings, get_system_prompt

ModelName = Literal["gpt-4o-mini", "gpt-4o"]


class ModelRouter:
    def __init__(self) -> None:
        settings = get_settings()
        self.client = OpenAI(api_key=settings.openai_api_key)
        self.system_prompt = get_system_prompt()

    def choose_model(self, use_premium: bool) -> ModelName:
        if use_premium:
            return "gpt-4o"
        return "gpt-4o-mini"

    def stream_chat_completion(
        self,
        messages: list[dict],
        use_premium: bool = False,
    ):
        model = self.choose_model(use_premium)
        return self.client.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": self.system_prompt}, *messages],
            stream=True,
        )

    def chat_completion(
        self,
        messages: list[dict],
        use_premium: bool = False,
        return_model_name: bool = False,
    ) -> Tuple[str, str] | str:
        model = self.choose_model(use_premium)
        completion = self.client.chat.completions.create(
            model=model,
            messages=[{"role": "system", "content": self.system_prompt}, *messages],
        )
        content = completion.choices[0].message.content or ""
        if return_model_name:
            return content, model
        return content


def get_model_router() -> ModelRouter:
    return ModelRouter()
