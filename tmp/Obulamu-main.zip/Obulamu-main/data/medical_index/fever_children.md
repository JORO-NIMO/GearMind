For children, organizations such as NHS and WHO recommend urgent assessment if a baby under 3 months has a temperature at or above 38°C (100.4°F), or a baby 3–6 months has a temperature at or above 39°C (102.2°F). Other warning signs include difficulty waking, pale or mottled skin, fast breathing, or a weak high-pitched cry.

