For common cold-type symptoms, many people can manage at home with rest, fluids, and over-the-counter remedies if they are suitable for the individual. Hand hygiene, covering coughs, and staying home when unwell can reduce spread. If symptoms last more than a couple of weeks, are very severe, or you are worried, a clinician should be consulted.

