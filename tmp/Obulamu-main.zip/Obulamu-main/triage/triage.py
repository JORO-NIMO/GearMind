from __future__ import annotations

from triage.rules import (
    EMERGENCY_KEYWORDS,
    URGENT_KEYWORDS,
    TriageResult,
    detect_keywords,
)


def triage_text(text: str) -> TriageResult:
    red_flags = detect_keywords(text, EMERGENCY_KEYWORDS)
    urgent_flags = detect_keywords(text, URGENT_KEYWORDS)

    if red_flags:
        advice = (
            "Your description contains possible emergency warning signs described by "
            "organizations such as the WHO and NHS. "
            "Do not wait to see if symptoms improve."
        )
        return TriageResult(
            category="Emergency",
            red_flags=red_flags,
            advice=advice,
            recommended_action=(
                "Call emergency services immediately (for example, 911 or your local emergency number)."
            ),
            recommended_setting="Emergency department / ambulance",
            use_premium_model=True,
        )

    if urgent_flags:
        advice = (
            "Your symptoms may require urgent medical assessment based on NHS and CDC guidance. "
            "They are not necessarily life-threatening, but should be assessed promptly."
        )
        return TriageResult(
            category="Urgent",
            red_flags=urgent_flags,
            advice=advice,
            recommended_action=(
                "Seek same-day medical care via urgent care, walk-in clinic, or your primary care provider."
            ),
            recommended_setting="Urgent care / primary care clinic",
            use_premium_model=True,
        )

    lowered = text.lower()
    if any(word in lowered for word in ["cough", "cold", "mild pain", "sore throat", "runny nose"]):
        advice = (
            "Your description suggests a self-limiting respiratory or minor symptom pattern without "
            "clear emergency red-flag features. Evidence-based sources (such as NHS and WHO self-care "
            "guidance) describe simple home measures that can ease symptoms:\n\n"
            "- Rest and avoid over-exertion so your body can recover.\n"
            "- Drink plenty of fluids (for example, water, diluted juice, clear soups) to stay hydrated.\n"
            "- For sore throat or mild aches, consider paracetamol/acetaminophen or ibuprofen only if "
            "you have used them safely before and do not have allergies, pregnancy concerns, stomach, "
            "kidney, liver, bleeding, or other conditions that make them unsafe.\n"
            "- For blocked nose or cough, non-prescription remedies (saline sprays, simple linctus, "
            "honey in warm drinks for adults) can be used if generally safe for you.\n"
            "- Avoid giving honey to children under 1 year old.\n\n"
            "However, even common colds and minor illnesses can sometimes become more serious, so "
            "contact a clinician if symptoms worsen, last longer than expected, or you feel unsafe."
        )
        return TriageResult(
            category="Self-care",
            red_flags=[],
            advice=advice,
            recommended_action=(
                "Use safe self-care measures at home (rest, fluids, simple over-the-counter remedies "
                "if appropriate for you) and monitor your symptoms for any red flags or worsening over time."
            ),
            recommended_setting="Home / self-care with safety net advice",
            use_premium_model=False,
        )

    advice = (
        "Your symptoms do not clearly match emergency warning signs, but a professional assessment "
        "can help clarify the cause and next steps. Evidence-based care from a qualified clinician "
        "is important if symptoms persist or concern you."
    )
    return TriageResult(
        category="Non-urgent",
        red_flags=[],
        advice=advice,
        recommended_action=(
            "Arrange a routine appointment with your primary care provider or appropriate local service."
        ),
        recommended_setting="Primary care / outpatient clinic",
        use_premium_model=False,
    )
