Within this triage module, keep rule definitions simple, transparent, and focused on high‑level safety guidance. Do not encode region‑specific emergency numbers beyond generic examples. Avoid adding probabilistic scoring; keep categories discrete and easy to explain.

