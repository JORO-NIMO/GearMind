const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000";

export interface User {
  id: number;
  email: string;
  is_active: boolean;
  is_premium: boolean;
  session_count: number;
  subscription_status: string;
  subscription_id?: string | null;
}

export interface ChatResponse {
  reply: string;
  model_name: string;
  retrieval_context: string;
}

export interface SubscriptionCreateResponse {
  subscription_id: string;
  approval_url: string;
}

export interface SubscriptionStatusResponse {
  subscription_id?: string | null;
  status: string;
  is_premium: boolean;
}

async function apiRequest<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || response.statusText);
  }

  return (await response.json()) as T;
}

export async function register(
  email: string,
  password: string,
): Promise<User> {
  return apiRequest<User>("/auth/register", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
}

export async function login(
  email: string,
  password: string,
): Promise<{ token: string }> {
  const body = new URLSearchParams();
  body.set("username", email);
  body.set("password", password);

  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  });

  if (!response.ok) {
    const text = await response.text();
    throw new Error(text || response.statusText);
  }

  const data = (await response.json()) as { access_token: string };
  return { token: data.access_token };
}

export async function getCurrentUser(token: string): Promise<User> {
  return apiRequest<User>("/auth/me", {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

export async function sendChatMessage(
  token: string,
  text: string,
): Promise<ChatResponse> {
  return apiRequest<ChatResponse>("/chat", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ text, include_history: true }),
  });
}

export async function createSubscription(
  token: string,
): Promise<SubscriptionCreateResponse> {
  return apiRequest<SubscriptionCreateResponse>("/subscribe", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });
}

export async function verifySubscription(
  token: string,
  subscriptionId?: string | null,
): Promise<SubscriptionStatusResponse> {
  return apiRequest<SubscriptionStatusResponse>("/subscribe/verify", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      subscription_id: subscriptionId ?? undefined,
    }),
  });
}

