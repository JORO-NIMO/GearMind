from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import inspect, text
from sqlalchemy.orm import Session
import os
import threading
import requests
import time


from app.api.routes_auth import router as auth_router
from app.api.routes_chat import router as chat_router
from app.api.routes_health import router as health_router
from app.api.routes_logs import router as logs_router
from app.api.routes_triage import router as triage_router
from app.api.routes_payments import router as payments_router
from app.db.database import Base, SessionLocal, engine
from app.models.user import User
from app.auth import get_password_hash
from config.settings import get_settings

app = FastAPI(title="MyHealthBot API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _run_migrations() -> None:
    inspector = inspect(engine)
    if "users" not in inspector.get_table_names():
        return
    existing_columns = {col["name"] for col in inspector.get_columns("users")}
    with engine.begin() as conn:
        if "subscription_status" not in existing_columns:
            conn.execute(
                text(
                    "ALTER TABLE users ADD COLUMN subscription_status VARCHAR(50) DEFAULT 'none'"
            )
            )


def _ensure_superuser() -> None:
    settings = get_settings()
    if not settings.superuser_email or not settings.superuser_password:
        return
    db: Session = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == settings.superuser_email).first()
        if existing is not None:
            if not existing.is_premium:
                existing.is_premium = True
                existing.subscription_status = "superuser"
                db.add(existing)
                db.commit()
            return
        user = User(
            email=settings.superuser_email,
            hashed_password=get_password_hash(settings.superuser_password),
            is_active=True,
            is_premium=True,
            subscription_status="superuser",
        )
        db.add(user)
        db.commit()
    finally:
        db.close()
        if "subscription_id" not in existing_columns:
            conn.execute(
                text(
                    "ALTER TABLE users ADD COLUMN subscription_id VARCHAR(191)"
                )
            )


@app.on_event("startup")
def on_startup() -> None:
    Base.metadata.create_all(bind=engine)
    _run_migrations()
    _ensure_superuser()


app.include_router(health_router)
app.include_router(auth_router)
app.include_router(triage_router)
app.include_router(chat_router)
app.include_router(logs_router)
app.include_router(payments_router)


@app.get("/")
def read_root() -> dict:
    return {"message": "MyHealthBot backend is running."}

@app.get("/ping")
async def ping():
    return {"status": "pong"}

# -----------------
# SELF-PING FUNCTION
# -----------------
def keep_alive():
    while True:
        try:
            url = os.environ.get("BASE_URL")
            if url:
                requests.get(url, timeout=5)
                print("Self-ping successful")
        except Exception as e:
            print(f"Self-ping failed: {e}")
        time.sleep(300) 

# -----------------
# START BACKGROUND THREAD
# -----------------
threading.Thread(target=keep_alive, daemon=True).start()
