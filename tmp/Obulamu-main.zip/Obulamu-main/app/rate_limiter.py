from __future__ import annotations

import time
from collections import defaultdict
from typing import Dict, List

from fastapi import HTTPException, status

from app.models.user import User
from config.settings import get_settings

_request_log: Dict[int, List[float]] = defaultdict(list)


def check_rate_limit(user: User) -> None:
    settings = get_settings()
    now = time.time()
    window_seconds = 60.0
    max_requests = settings.max_requests_per_minute

    timestamps = _request_log[user.id]
    cutoff = now - window_seconds
    filtered = [t for t in timestamps if t > cutoff]
    filtered.append(now)
    _request_log[user.id] = filtered

    if len(filtered) > max_requests:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Too many requests, please slow down.",
        )
