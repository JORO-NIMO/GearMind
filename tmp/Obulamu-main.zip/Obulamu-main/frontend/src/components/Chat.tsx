import React, { useState } from "react";
import type { ChatResponse, User } from "../api";
import { PayPalSubscriptionButton } from "./PayPalSubscriptionButton";

interface ChatProps {
  user: User;
  token: string;
  onSend: (text: string) => Promise<ChatResponse>;
  onSubscribe: () => Promise<void>;
}

export const Chat: React.FC<ChatProps> = ({
  user,
  token,
  onSend,
  onSubscribe,
}) => {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [messages, setMessages] = useState<
    { role: "user" | "assistant"; content: string }[]
  >([]);
  const [trialExceeded, setTrialExceeded] = useState(false);

  const remainingTrials = Math.max(0, 10 - user.session_count);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;
    setError(null);
    setLoading(true);
    const text = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: text }]);
    try {
      const response = await onSend(text);
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: response.reply },
      ]);
      setTrialExceeded(false);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Failed to send message";
      setError(message);
      if (message.includes("Free trial limit reached")) {
        setTrialExceeded(true);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async () => {
    // This handler remains available for future upgrades,
    // but the primary PayPal entry point is now the inline PayPal button.
  };

  const handleDownloadTranscript = () => {
    if (messages.length === 0) {
      return;
    }
    const lines: string[] = [];
    lines.push("Obulamu conversation\n");
    for (const m of messages) {
      const label = m.role === "user" ? "You" : "Obulamu";
      lines.push(`${label}: ${m.content}\n`);
    }
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "obulamu-conversation.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="mx-auto flex h-screen max-w-3xl flex-col px-4 py-6">
      <header className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-50">
            Obulamu Chat
          </h1>
          <p className="text-sm text-slate-400">
            Logged in as <span className="font-medium">{user.email}</span>
          </p>
        </div>
        <div className="flex flex-col items-start gap-2 sm:items-end">
          <div className="text-right">
            <p className="text-sm text-slate-300">
              Subscription:{" "}
              <span className="font-semibold">
                {user.is_premium ? "Active" : user.subscription_status || "None"}
              </span>
            </p>
            <p className="text-xs text-slate-400">
              Free queries used:{" "}
              <span className="font-mono">
                {user.session_count} / 10
              </span>
            </p>
          </div>
          <button
            type="button"
            onClick={handleDownloadTranscript}
            className="inline-flex items-center rounded-md border border-slate-600 px-3 py-1 text-xs font-medium text-slate-100 hover:bg-slate-800"
          >
            Download conversation
          </button>
        </div>
      </header>

      <main className="flex flex-1 flex-col overflow-hidden rounded-lg border border-slate-800 bg-slate-900/60">
        <div className="flex-1 space-y-3 overflow-y-auto p-4 text-sm">
          {messages.length === 0 && (
            <p className="text-slate-400">
              Ask a question about your symptoms. This assistant does not
              provide diagnoses and will always encourage you to seek care
              according to medical safety guidelines.
            </p>
          )}
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={
                m.role === "user"
                  ? "flex justify-end"
                  : "flex justify-start"
              }
            >
              <div
                className={
                  m.role === "user"
                    ? "max-w-[80%] rounded-2xl bg-blue-600 px-3 py-2 text-sm text-white"
                    : "max-w-[80%] rounded-2xl bg-slate-800 px-3 py-2 text-sm text-slate-50"
                }
              >
                {m.content}
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-800 bg-slate-900/80 p-3">
          {!user.is_premium && (
            <div className="mb-2 flex items-center justify-between text-xs text-slate-400">
              <span>
                Free trial:{" "}
                <span className="font-semibold">
                  {remainingTrials} queries remaining
                </span>
              </span>
              <span>$5/month after trial</span>
            </div>
          )}

          {trialExceeded && (
            <div className="mb-2 rounded-md bg-amber-500/10 px-3 py-2 text-xs text-amber-300">
              You&apos;ve used all 10 free queries. Subscribe for $5/month to
              continue using Obulamu.
            </div>
          )}

          {error && (
            <div className="mb-2 rounded-md bg-red-500/10 px-3 py-2 text-xs text-red-300">
              {error}
            </div>
          )}

          <form onSubmit={handleSend} className="flex items-end gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="h-16 flex-1 resize-none rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-50 outline-none ring-blue-500/60 focus:ring-1"
              placeholder="Describe your symptoms or ask a question..."
            />
            <button
              type="submit"
              disabled={loading || !token}
              className="inline-flex h-10 items-center rounded-md bg-blue-600 px-4 text-sm font-medium text-white shadow-sm transition hover:bg-blue-500 disabled:cursor-not-allowed disabled:bg-slate-600"
            >
              {loading ? "Sending..." : "Send"}
            </button>
          </form>

          {!user.is_premium && (
            <div className="mt-3 space-y-2">
              <p className="text-xs text-slate-400">
                Want unlimited access? You can subscribe for $5/month via the PayPal button below.
              </p>
              <PayPalSubscriptionButton userId={user.id} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
};
