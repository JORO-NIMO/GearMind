from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, EmailStr, Field


class UserBase(BaseModel):
    email: EmailStr


class UserCreate(UserBase):
    password: str = Field(min_length=8)


class UserRead(UserBase):
    id: int
    is_active: bool
    is_premium: bool
    session_count: int
    subscription_status: str
    subscription_id: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    email: Optional[EmailStr] = None


class MessageRead(BaseModel):
    id: int
    role: str
    content: str
    created_at: datetime

    class Config:
        from_attributes = True


class TriageRequest(BaseModel):
    text: str


class TriageResultSchema(BaseModel):
    category: str
    red_flags: List[str]
    advice: str
    recommended_action: str
    recommended_setting: str
    use_premium_model: bool


class TriageResponse(TriageResultSchema):
    pass


class ChatRequest(BaseModel):
    text: str
    include_history: bool = True


class ChatResponse(BaseModel):
    reply: str
    triage: TriageResultSchema
    retrieval_context: str
    model_name: str


class DailyLogsRequest(BaseModel):
    logs: List[str]


class DailyLogsResponse(BaseModel):
    summary: str


class SubscriptionCreateResponse(BaseModel):
    subscription_id: str
    approval_url: str


class SubscriptionVerifyRequest(BaseModel):
    subscription_id: Optional[str] = None


class SubscriptionStatusResponse(BaseModel):
    subscription_id: Optional[str]
    status: str
    is_premium: bool
