from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import List

from rank_bm25 import BM25Okapi

from retrieval.preprocess import normalize_text, preprocess_documents


@dataclass
class BM25Index:
    bm25: BM25Okapi
    documents: list[str]


def load_medical_corpus(base_path: Path) -> list[str]:
    docs: list[str] = []
    for path in sorted(base_path.glob("*.md")):
        docs.append(path.read_text(encoding="utf-8"))
    return docs


def build_bm25_index(base_path: Path) -> BM25Index:
    raw_docs = load_medical_corpus(base_path)
    if not raw_docs:
        raise RuntimeError(f"No medical snippets found in {base_path}")
    processed_docs = preprocess_documents(raw_docs)
    tokenized_corpus: List[List[str]] = [doc.split() for doc in processed_docs]
    bm25 = BM25Okapi(tokenized_corpus)
    return BM25Index(bm25=bm25, documents=processed_docs)


def summarize_snippet(snippet: str, max_length: int = 400) -> str:
    snippet = normalize_text(snippet)
    if len(snippet) <= max_length:
        return snippet
    return snippet[: max_length - 3] + "..."
