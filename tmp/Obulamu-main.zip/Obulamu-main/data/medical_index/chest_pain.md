Chest pain can have many causes. According to NHS and similar services, emergency care is needed if chest pain is sudden, severe, or feels like pressure, heaviness, or tightness that may spread to the arms, neck, jaw, back, or stomach, especially with shortness of breath, sweating, nausea, or feeling faint.

