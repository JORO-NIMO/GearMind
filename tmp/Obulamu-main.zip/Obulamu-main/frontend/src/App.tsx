import React, { useEffect, useState } from "react";
import {
  ChatResponse,
  User,
  createSubscription,
  getCurrentUser,
  login,
  register,
  sendChatMessage,
  verifySubscription,
} from "./api";
import { Chat } from "./components/Chat";

type AuthMode = "login" | "register";

const TOKEN_KEY = "Obulamu_token";

const useQueryParam = (key: string): string | null => {
  const params = new URLSearchParams(window.location.search);
  const value = params.get(key);
  return value;
};

const SubscriptionResult: React.FC<{
  kind: "success" | "cancel";
}> = ({ kind }) => {
  const [status, setStatus] = useState<string>("Verifying subscription...");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = window.localStorage.getItem(TOKEN_KEY);
    if (!token) {
      setError("You need to log in to link your subscription.");
      setStatus("");
      return;
    }

    const subscriptionId = useQueryParam("subscription_id");

    if (kind === "cancel") {
      setStatus("Subscription was cancelled. You can try again from the app.");
      return;
    }

    verifySubscription(token, subscriptionId)
      .then((result) => {
        if (result.is_premium && result.status === "active") {
          setStatus("Subscription activated. Redirecting to chat...");
          setTimeout(() => {
            window.location.href = "/";
          }, 1500);
        } else {
          setStatus(
            `Subscription status: ${result.status}. You may need to retry.`,
          );
        }
      })
      .catch((err) => {
        const message =
          err instanceof Error ? err.message : "Failed to verify subscription";
        setError(message);
        setStatus("");
      });
  }, [kind]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4">
      <div className="w-full max-w-md rounded-lg border border-slate-800 bg-slate-900/70 p-6 shadow-xl">
        <h1 className="mb-2 text-xl font-semibold text-slate-50">
          {kind === "success"
            ? "PayPal Subscription Success"
            : "PayPal Subscription Cancelled"}
        </h1>
        {status && <p className="mb-3 text-sm text-slate-300">{status}</p>}
        {error && (
          <p className="text-sm text-red-300">
            {error}
          </p>
        )}
        <button
          type="button"
          onClick={() => {
            window.location.href = "/";
          }}
          className="mt-4 inline-flex items-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500"
        >
          Back to app
        </button>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [authMode, setAuthMode] = useState<AuthMode>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [installPromptEvent, setInstallPromptEvent] = useState<any | null>(null);
  const [canInstall, setCanInstall] = useState(false);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setInstallPromptEvent(e);
      setCanInstall(true);
    };
    window.addEventListener("beforeinstallprompt", handler as any);
    return () => {
      window.removeEventListener("beforeinstallprompt", handler as any);
    };
  }, []);

  const handleInstallApp = async () => {
    if (!installPromptEvent) return;
    installPromptEvent.prompt();
    await installPromptEvent.userChoice;
    setInstallPromptEvent(null);
    setCanInstall(false);
  };

  useEffect(() => {
    const savedToken = window.localStorage.getItem(TOKEN_KEY);
    if (!savedToken) return;
    setToken(savedToken);
    getCurrentUser(savedToken)
      .then((u) => {
        setUser(u);
      })
      .catch(() => {
        window.localStorage.removeItem(TOKEN_KEY);
        setToken(null);
      });
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      if (authMode === "register") {
        await register(email, password);
      }
      const { token: newToken } = await login(email, password);
      window.localStorage.setItem(TOKEN_KEY, newToken);
      setToken(newToken);
      const me = await getCurrentUser(newToken);
      setUser(me);
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Authentication failed";
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    window.localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    setToken(null);
  };

  const handleSend = async (text: string): Promise<ChatResponse> => {
    if (!token) {
      throw new Error("Not authenticated");
    }
    const response = await sendChatMessage(token, text);
    const updatedUser = await getCurrentUser(token);
    setUser(updatedUser);
    return response;
  };

  const handleSubscribe = async () => {
    if (!token) {
      throw new Error("Not authenticated");
    }
    const result = await createSubscription(token);
    window.location.href = result.approval_url;
  };

  const path = window.location.pathname;
  if (path.startsWith("/subscription/success")) {
    return <SubscriptionResult kind="success" />;
  }
  if (path.startsWith("/subscription/cancel")) {
    return <SubscriptionResult kind="cancel" />;
  }

  if (!user || !token) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 px-4">
        <div className="w-full max-w-md rounded-lg border border-slate-800 bg-slate-900/70 p-6 shadow-xl">
          <h1 className="mb-2 text-xl font-semibold text-slate-50">
            Obulamu
          </h1>
          <p className="mb-4 text-sm text-slate-400">
            Sign in or create an account to start your 10-message free trial.
          </p>

          <div className="mb-4 flex gap-2 text-sm">
            <button
              type="button"
              onClick={() => {
                setAuthMode("login");
                setError(null);
              }}
              className={
                authMode === "login"
                  ? "flex-1 rounded-md bg-blue-600 px-3 py-2 font-medium text-white"
                  : "flex-1 rounded-md bg-slate-800 px-3 py-2 text-slate-300"
              }
            >
              Log in
            </button>
            <button
              type="button"
              onClick={() => {
                setAuthMode("register");
                setError(null);
              }}
              className={
                authMode === "register"
                  ? "flex-1 rounded-md bg-blue-600 px-3 py-2 font-medium text-white"
                  : "flex-1 rounded-md bg-slate-800 px-3 py-2 text-slate-300"
              }
            >
              Register
            </button>
          </div>

          {error && (
            <div className="mb-3 rounded-md bg-red-500/10 px-3 py-2 text-xs text-red-300">
              {error}
            </div>
          )}

          <form onSubmit={handleAuth} className="space-y-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-50 outline-none ring-blue-500/60 focus:ring-1"
                required
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-300">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-50 outline-none ring-blue-500/60 focus:ring-1"
                required
                minLength={8}
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="mt-1 inline-flex w-full items-center justify-center rounded-md bg-blue-600 px-3 py-2 text-sm font-medium text-white hover:bg-blue-500 disabled:cursor-not-allowed disabled:bg-slate-600"
            >
              {loading
                ? authMode === "login"
                  ? "Logging in..."
                  : "Registering..."
                : authMode === "login"
                  ? "Log in"
                  : "Register"}
            </button>
          </form>

          <p className="mt-4 text-xs text-slate-500">
            You&apos;ll receive 10 free messages to try Obulamu. After that,
            you can subscribe for $5/month via PayPal to continue.
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Chat
        user={user}
        token={token}
        onSend={handleSend}
        onSubscribe={handleSubscribe}
      />
      <button
        type="button"
        onClick={handleLogout}
        className="fixed right-4 top-4 rounded-md bg-slate-800 px-3 py-1 text-xs text-slate-200 hover:bg-slate-700"
      >
        Log out
      </button>
      {canInstall && (
        <button
          type="button"
          onClick={handleInstallApp}
          className="fixed bottom-4 left-4 rounded-md bg-slate-800 px-3 py-1 text-xs text-slate-200 shadow hover:bg-slate-700"
        >
          Add Obulamu to desktop
        </button>
      )}
    </>
  );
};

export default App;
