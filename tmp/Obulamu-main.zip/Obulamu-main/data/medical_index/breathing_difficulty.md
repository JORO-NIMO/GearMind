Sudden or severe difficulty breathing, gasping for air, or breathing so hard that speaking is difficult can signal a medical emergency. WHO and CDC highlight that blue or grey lips or face, severe wheezing, or noisy breathing at rest require immediate emergency assessment.

