Headaches are often mild and improve with rest, hydration, and simple pain relief if appropriate. NHS guidance suggests emergency care for a sudden severe “worst ever” headache, headache with weakness, confusion, seizure, or changes in vision, or headache after a significant head injury.

