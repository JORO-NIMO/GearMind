from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List

from retrieval.indexer import BM25Index, build_bm25_index, summarize_snippet


@dataclass
class RetrievedSnippet:
    text: str
    score: float


class RetrievalService:
    def __init__(self, index_path: Path) -> None:
        self.index_path = index_path
        self._index: BM25Index | None = None

    def _ensure_index(self) -> BM25Index:
        if self._index is None:
            self._index = build_bm25_index(self.index_path)
        return self._index

    def search(self, query: str, k: int = 5) -> list[RetrievedSnippet]:
        index = self._ensure_index()
        tokenized_query: List[str] = query.split()
        scores = index.bm25.get_scores(tokenized_query)
        scored_snippets: list[tuple[int, float]] = sorted(
            enumerate(scores), key=lambda x: x[1], reverse=True
        )[:k]
        results: list[RetrievedSnippet] = []
        for idx, score in scored_snippets:
            snippet = index.documents[idx]
            results.append(
                RetrievedSnippet(text=summarize_snippet(snippet), score=float(score))
            )
        return results

    def search_as_dicts(self, query: str, k: int = 5) -> list[dict]:
        return [asdict(s) for s in self.search(query, k=k)]


def get_retrieval_service(base_path: Path) -> RetrievalService:
    return RetrievalService(index_path=base_path)
