from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    openai_api_key: str = Field(..., alias="OPENAI_API_KEY")
    database_url: str = Field("sqlite:///./obulamu.db", alias="DATABASE_URL")
    jwt_secret: str = Field(..., alias="JWT_SECRET")
    jwt_algorithm: str = Field("HS256", alias="JWT_ALGORITHM")
    access_token_expire_minutes: int = Field(60, alias="ACCESS_TOKEN_EXPIRE_MINUTES")
    environment: str = Field("development", alias="ENVIRONMENT")
    free_trial_messages: int = Field(10, alias="FREE_TRIAL_MESSAGES")
    max_requests_per_minute: int = Field(30, alias="MAX_REQUESTS_PER_MINUTE")
    paypal_client_id: str | None = Field(default=None, alias="PAYPAL_CLIENT_ID")
    paypal_secret: str | None = Field(default=None, alias="PAYPAL_SECRET")
    paypal_environment: str = Field("sandbox", alias="PAYPAL_ENVIRONMENT")
    paypal_plan_id: str | None = Field(default=None, alias="PAYPAL_PLAN_ID")
    paypal_webhook_id: str | None = Field(default=None, alias="PAYPAL_WEBHOOK_ID")
    paypal_return_url: str | None = Field(default=None, alias="PAYPAL_RETURN_URL")
    paypal_cancel_url: str | None = Field(default=None, alias="PAYPAL_CANCEL_URL")
    superuser_email: str | None = Field(default=None, alias="SUPERUSER_EMAIL")
    superuser_password: str | None = Field(default=None, alias="SUPERUSER_PASSWORD")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache
def get_settings() -> "Settings":
    return Settings()  # type: ignore[arg-type]


def get_project_root() -> Path:
    return Path(__file__).resolve().parents[1]


def get_system_prompt() -> str:
    root = get_project_root()
    prompt_path = root / "config" / "system_prompt.txt"
    return prompt_path.read_text(encoding="utf-8")
