from __future__ import annotations

from typing import Iterable

from openai import OpenAI

from config.settings import get_settings, get_system_prompt


class BatchInferenceService:
    """
    Cheap batching of daily symptom logs using gpt-4o-mini.
    """

    def __init__(self) -> None:
        settings = get_settings()
        self.client = OpenAI(api_key=settings.openai_api_key)
        self.system_prompt = get_system_prompt()
        self.model = "gpt-4o-mini"

    def summarize_daily_logs(self, logs: Iterable[str]) -> str:
        joined = "\n\n".join(f"- {entry}" for entry in logs)
        messages = [
            {"role": "system", "content": self.system_prompt},
            {
                "role": "user",
                "content": (
                    "You are preparing a concise, patient-friendly daily symptom summary.\n\n"
                    "Symptom entries:\n"
                    f"{joined}\n\n"
                    "Summarize trends and key concerns in clear language, without diagnosing "
                    "or prescribing. Encourage appropriate follow-up with a clinician."
                ),
            },
        ]
        completion = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
        )
        return completion.choices[0].message.content or ""


def get_batch_inference_service() -> BatchInferenceService:
    return BatchInferenceService()
