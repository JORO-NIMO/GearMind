Most short-lived mild abdominal pain is not serious and can relate to digestion. However, sources like NHS advise urgent care if pain is severe and sudden, if the abdomen is hard or swollen, if there is vomiting that will not stop, if there is blood in vomit or stool, or if pain follows an injury.

