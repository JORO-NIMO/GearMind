from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.db.database import get_db
from app.models.message import Message
from app.models.user import User
from app.rate_limiter import check_rate_limit
from app.schemas import ChatRequest, ChatResponse, TriageResultSchema
from app.services.model_router import ModelRouter, get_model_router
from app.services.retrieval_service import (
    MedicalRetrievalService,
    get_medical_retrieval_service,
)
from app.services.triage_service import TriageService, get_triage_service
from config.settings import get_settings

router = APIRouter(prefix="/chat", tags=["chat"])


def _build_user_prompt(payload: ChatRequest, triage_result, retrieval_context: str) -> str:
    return (
        "You are assisting a patient with questions about their symptoms.\n\n"
        "User symptom description:\n"
        f"{payload.text}\n\n"
        "Triage assessment (do not override safety advice):\n"
        f"Category: {triage_result.category}\n"
        f"Advice: {triage_result.advice}\n"
        f"Recommended action: {triage_result.recommended_action}\n\n"
        "Retrieved medical context (for information only, not as a diagnosis tool):\n"
        f"{retrieval_context}\n\n"
        "Using the information above, provide clear, empathetic, and cautious guidance. "
        "Do not diagnose or prescribe. Encourage the user to seek care according to the "
        "triage recommendations and their local clinical services."
    )


def _get_history_messages(db: Session, current_user: User, include_history: bool) -> List[dict]:
    history_messages: List[dict] = []
    if include_history:
        past_messages = (
            db.query(Message)
            .filter(Message.user_id == current_user.id)
            .order_by(Message.created_at.desc())
            .limit(10)
            .all()
        )
        for msg in reversed(past_messages):
            history_messages.append({"role": msg.role, "content": msg.content})
    return history_messages


def _increment_trial_usage(db: Session, current_user: User) -> None:
    settings = get_settings()
    if not current_user.is_premium:
        if current_user.session_count >= settings.free_trial_messages:
            raise HTTPException(
                status_code=status.HTTP_402_PAYMENT_REQUIRED,
                detail="Free trial limit reached. Upgrade to continue.",
            )
        current_user.session_count += 1
        db.add(current_user)
        db.commit()
        db.refresh(current_user)


@router.post("/", response_model=ChatResponse)
def chat_endpoint(
    payload: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    triage_service: TriageService = Depends(get_triage_service),
    retrieval_service: MedicalRetrievalService = Depends(get_medical_retrieval_service),
    model_router: ModelRouter = Depends(get_model_router),
) -> ChatResponse:
    check_rate_limit(current_user)
    triage_result = triage_service.triage(payload.text)

    retrieval_context = retrieval_service.format_snippets_as_context(payload.text, k=5)

    history_messages = _get_history_messages(db, current_user, payload.include_history)

    user_content = _build_user_prompt(payload, triage_result, retrieval_context)
    messages = [
        *history_messages,
        {"role": "user", "content": user_content},
    ]

    reply_text, model_name = model_router.chat_completion(
        messages=messages,
        use_premium=triage_result.use_premium_model,
        return_model_name=True,
    )

    _increment_trial_usage(db, current_user)

    user_message = Message(
        user_id=current_user.id,
        role="user",
        content=payload.text,
    )
    assistant_message = Message(
        user_id=current_user.id,
        role="assistant",
        content=reply_text,
    )
    db.add_all([user_message, assistant_message])
    db.commit()

    triage_schema = TriageResultSchema(
        category=triage_result.category,
        red_flags=triage_result.red_flags,
        advice=triage_result.advice,
        recommended_action=triage_result.recommended_action,
        recommended_setting=triage_result.recommended_setting,
        use_premium_model=triage_result.use_premium_model,
    )

    return ChatResponse(
        reply=reply_text,
        triage=triage_schema,
        retrieval_context=retrieval_context,
        model_name=model_name,
    )


@router.post("/stream")
def chat_stream_endpoint(
    payload: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    triage_service: TriageService = Depends(get_triage_service),
    retrieval_service: MedicalRetrievalService = Depends(get_medical_retrieval_service),
    model_router: ModelRouter = Depends(get_model_router),
) -> StreamingResponse:
    check_rate_limit(current_user)
    triage_result = triage_service.triage(payload.text)
    retrieval_context = retrieval_service.format_snippets_as_context(payload.text, k=5)
    history_messages = _get_history_messages(db, current_user, payload.include_history)
    user_content = _build_user_prompt(payload, triage_result, retrieval_context)
    messages = [
        *history_messages,
        {"role": "user", "content": user_content},
    ]

    stream = model_router.stream_chat_completion(
        messages=messages,
        use_premium=triage_result.use_premium_model,
    )

    def event_generator():
        full_reply_parts: List[str] = []
        for chunk in stream:
            delta = chunk.choices[0].delta.content or ""
            if delta:
                full_reply_parts.append(delta)
                yield delta
        full_reply_text = "".join(full_reply_parts)
        _increment_trial_usage(db, current_user)
        user_message = Message(
            user_id=current_user.id,
            role="user",
            content=payload.text,
        )
        assistant_message = Message(
            user_id=current_user.id,
            role="assistant",
            content=full_reply_text,
        )
        db.add_all([user_message, assistant_message])
        db.commit()

    return StreamingResponse(event_generator(), media_type="text/plain")
