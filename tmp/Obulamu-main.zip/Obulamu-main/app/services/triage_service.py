from __future__ import annotations

from triage.triage import TriageResult, triage_text


class TriageService:
    def triage(self, text: str) -> TriageResult:
        return triage_text(text)


def get_triage_service() -> TriageService:
    return TriageService()

