from __future__ import annotations

from fastapi import APIRouter, Depends

from app.schemas import DailyLogsRequest, DailyLogsResponse
from app.services.batch_inference import (
    BatchInferenceService,
    get_batch_inference_service,
)

router = APIRouter(prefix="/logs", tags=["logs"])


@router.post("/summary", response_model=DailyLogsResponse)
def summarize_logs(
    payload: DailyLogsRequest,
    batch_service: BatchInferenceService = Depends(get_batch_inference_service),
) -> DailyLogsResponse:
    summary = batch_service.summarize_daily_logs(payload.logs)
    return DailyLogsResponse(summary=summary)
