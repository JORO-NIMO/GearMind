For retrieval components, prioritize deterministic, transparent behavior. Do not introduce network calls or external search. Use only the local corpus under data/medical_index and keep index construction light enough for typical free‑tier hosting.

