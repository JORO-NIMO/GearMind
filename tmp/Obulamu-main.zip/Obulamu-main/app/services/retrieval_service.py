from __future__ import annotations

from config.settings import get_project_root
from retrieval.search import RetrievalService, get_retrieval_service


class MedicalRetrievalService:
    def __init__(self) -> None:
        root = get_project_root()
        base_path = root / "data" / "medical_index"
        self._service: RetrievalService = get_retrieval_service(base_path)

    def get_snippets(self, query: str, k: int = 5) -> list[dict]:
        return self._service.search_as_dicts(query, k=k)

    def format_snippets_as_context(self, query: str, k: int = 5) -> str:
        snippets = self.get_snippets(query, k=k)
        lines: list[str] = []
        for i, sn in enumerate(snippets, start=1):
            lines.append(f"[Snippet {i} | score={sn['score']:.2f}]\n{sn['text']}")
        return "\n\n".join(lines)


def get_medical_retrieval_service() -> MedicalRetrievalService:
    return MedicalRetrievalService()
