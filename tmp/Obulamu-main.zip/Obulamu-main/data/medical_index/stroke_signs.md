Stroke warning signs described by public health campaigns include sudden weakness or numbness on one side of the body, face drooping, sudden trouble speaking, confusion, sudden trouble seeing, loss of balance, or a sudden severe headache. Emergency services should be contacted immediately if stroke is suspected.

