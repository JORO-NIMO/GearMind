from __future__ import annotations

import json
from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy.orm import Session

from app.auth import get_current_active_user
from app.db.database import get_db
from app.models.user import User
from app.schemas import (
    SubscriptionCreateResponse,
    SubscriptionStatusResponse,
    SubscriptionVerifyRequest,
)
from app.services.paypal import (
    PayPalAPIError,
    PayPalConfigurationError,
    PayPalClient,
    get_paypal_client,
)
from config.settings import get_settings

router = APIRouter(tags=["billing"])


@router.post("/subscribe", response_model=SubscriptionCreateResponse)
def create_subscription(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    paypal_client: PayPalClient = Depends(get_paypal_client),
) -> SubscriptionCreateResponse:
    settings = get_settings()
    if not settings.paypal_plan_id:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PayPal plan ID is not configured",
        )
    try:
        result = paypal_client.create_subscription(
            plan_id=settings.paypal_plan_id,
            custom_id=str(current_user.id),
            return_url=settings.paypal_return_url,
            cancel_url=settings.paypal_cancel_url,
        )
    except (PayPalConfigurationError, PayPalAPIError) as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc

    subscription_id = result.get("id")
    if not subscription_id:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="PayPal did not return a subscription ID",
        )

    approval_url = None
    for link in result.get("links", []):
        if link.get("rel") == "approve":
            approval_url = link.get("href")
            break

    if not approval_url:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="PayPal approval URL not found in response",
        )

    current_user.subscription_id = subscription_id
    current_user.subscription_status = "pending"
    db.add(current_user)
    db.commit()
    db.refresh(current_user)

    return SubscriptionCreateResponse(
        subscription_id=subscription_id,
        approval_url=approval_url,
    )


@router.post("/subscribe/verify", response_model=SubscriptionStatusResponse)
def verify_subscription(
    payload: SubscriptionVerifyRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
    paypal_client: PayPalClient = Depends(get_paypal_client),
) -> SubscriptionStatusResponse:
    subscription_id = payload.subscription_id or current_user.subscription_id
    if not subscription_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No subscription ID provided",
        )
    try:
        details = paypal_client.get_subscription_details(subscription_id)
    except PayPalAPIError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc

    status_str = (details.get("status") or "").lower()
    if status_str == "active":
        current_user.is_premium = True
        current_user.subscription_status = "active"
    elif status_str in {"cancelled", "suspended", "expired"}:
        current_user.is_premium = False
        current_user.subscription_status = status_str

    current_user.subscription_id = subscription_id
    db.add(current_user)
    db.commit()
    db.refresh(current_user)

    return SubscriptionStatusResponse(
        subscription_id=current_user.subscription_id,
        status=current_user.subscription_status,
        is_premium=current_user.is_premium,
    )


@router.post("/webhook/paypal")
async def paypal_webhook(
    request: Request,
    db: Session = Depends(get_db),
    paypal_client: PayPalClient = Depends(get_paypal_client),
) -> Dict[str, Any]:
    settings = get_settings()
    if not settings.paypal_webhook_id:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="PayPal webhook ID is not configured",
        )

    transmission_id = request.headers.get("Paypal-Transmission-Id")
    transmission_time = request.headers.get("Paypal-Transmission-Time")
    cert_url = request.headers.get("Paypal-Cert-Url")
    auth_algo = request.headers.get("Paypal-Auth-Algo")
    transmission_sig = request.headers.get("Paypal-Transmission-Sig")

    if not all([transmission_id, transmission_time, cert_url, auth_algo, transmission_sig]):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing PayPal webhook headers",
        )

    body_bytes = await request.body()
    try:
        event_body = json.loads(body_bytes.decode("utf-8"))
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid JSON body",
        )

    try:
        valid = paypal_client.verify_webhook_signature(
            transmission_id=transmission_id,
            transmission_time=transmission_time,
            cert_url=cert_url,
            auth_algo=auth_algo,
            transmission_sig=transmission_sig,
            webhook_id=settings.paypal_webhook_id,
            event_body=event_body,
        )
    except PayPalAPIError as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc

    if not valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid PayPal webhook signature",
        )

    event_type = (event_body.get("event_type") or "").upper()
    resource = event_body.get("resource") or {}
    subscription_id = resource.get("id") or resource.get("subscription_id")
    custom_id = resource.get("custom_id")
    status_str = (resource.get("status") or "").lower()

    user: User | None = None
    if custom_id:
        try:
            user_id = int(custom_id)
        except ValueError:
            user_id = None
        if user_id is not None:
            user = db.query(User).filter(User.id == user_id).first()
    if user is None and subscription_id:
        user = db.query(User).filter(User.subscription_id == subscription_id).first()

    if user is None:
        return {"status": "ignored"}

    if event_type == "BILLING.SUBSCRIPTION.ACTIVATED" or status_str == "active":
        user.is_premium = True
        user.subscription_status = "active"
        if subscription_id:
            user.subscription_id = subscription_id
    elif event_type in {
        "BILLING.SUBSCRIPTION.CANCELLED",
        "BILLING.SUBSCRIPTION.SUSPENDED",
        "BILLING.SUBSCRIPTION.EXPIRED",
    } or status_str in {"cancelled", "suspended", "expired"}:
        user.is_premium = False
        user.subscription_status = status_str or "cancelled"

    db.add(user)
    db.commit()

    return {"status": "ok"}

