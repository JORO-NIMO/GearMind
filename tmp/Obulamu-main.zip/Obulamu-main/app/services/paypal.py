from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Any, Dict, Optional

import requests

from config.settings import get_settings


class PayPalConfigurationError(Exception):
    pass


class PayPalAPIError(Exception):
    pass


@dataclass
class PayPalClient:
    client_id: str
    secret: str
    environment: str

    def _base_url(self) -> str:
        if self.environment.lower() == "live":
            return "https://api-m.paypal.com"
        return "https://api-m.sandbox.paypal.com"

    def _get_access_token(self) -> str:
        url = f"{self._base_url()}/v1/oauth2/token"
        auth_header = base64.b64encode(f"{self.client_id}:{self.secret}".encode("utf-8")).decode(
            "utf-8"
        )
        headers = {
            "Authorization": f"Basic {auth_header}",
            "Content-Type": "application/x-www-form-urlencoded",
        }
        response = requests.post(url, headers=headers, data={"grant_type": "client_credentials"})
        if not response.ok:
            raise PayPalAPIError(f"Failed to obtain PayPal access token: {response.text}")
        data = response.json()
        token = data.get("access_token")
        if not token:
            raise PayPalAPIError("PayPal access token missing in response")
        return token

    def create_subscription(
        self,
        plan_id: str,
        custom_id: str,
        return_url: Optional[str],
        cancel_url: Optional[str],
    ) -> Dict[str, Any]:
        url = f"{self._base_url()}/v1/billing/subscriptions"
        token = self._get_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        if not return_url or not cancel_url:
            raise PayPalConfigurationError("PayPal return/cancel URLs are not configured")

        payload: Dict[str, Any] = {
            "plan_id": plan_id,
            "custom_id": custom_id,
            "application_context": {
                "brand_name": "MyHealthBot",
                "user_action": "SUBSCRIBE_NOW",
                "return_url": return_url,
                "cancel_url": cancel_url,
            },
        }
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        if not response.ok:
            raise PayPalAPIError(f"Failed to create PayPal subscription: {response.text}")
        return response.json()

    def get_subscription_details(self, subscription_id: str) -> Dict[str, Any]:
        url = f"{self._base_url()}/v1/billing/subscriptions/{subscription_id}"
        token = self._get_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        response = requests.get(url, headers=headers)
        if not response.ok:
            raise PayPalAPIError(f"Failed to fetch PayPal subscription: {response.text}")
        return response.json()

    def verify_webhook_signature(
        self,
        transmission_id: str,
        transmission_time: str,
        cert_url: str,
        auth_algo: str,
        transmission_sig: str,
        webhook_id: str,
        event_body: Dict[str, Any],
    ) -> bool:
        url = f"{self._base_url()}/v1/notifications/verify-webhook-signature"
        token = self._get_access_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        payload = {
            "transmission_id": transmission_id,
            "transmission_time": transmission_time,
            "cert_url": cert_url,
            "auth_algo": auth_algo,
            "transmission_sig": transmission_sig,
            "webhook_id": webhook_id,
            "webhook_event": event_body,
        }
        response = requests.post(url, headers=headers, data=json.dumps(payload))
        if not response.ok:
            raise PayPalAPIError(f"Failed to verify PayPal webhook signature: {response.text}")
        data = response.json()
        return data.get("verification_status") == "SUCCESS"


def get_paypal_client() -> PayPalClient:
    settings = get_settings()
    if not settings.paypal_client_id or not settings.paypal_secret:
        raise PayPalConfigurationError("PayPal client ID/secret are not configured")
    return PayPalClient(
        client_id=settings.paypal_client_id,
        secret=settings.paypal_secret,
        environment=settings.paypal_environment,
    )

