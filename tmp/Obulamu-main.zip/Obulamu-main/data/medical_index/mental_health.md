For mental health, organizations such as WHO and NHS emphasize seeking immediate help if someone has thoughts of harming themselves or others, has plans to act on these thoughts, or feels unable to stay safe. Crisis and emergency services are available in many regions and should be contacted without delay.

