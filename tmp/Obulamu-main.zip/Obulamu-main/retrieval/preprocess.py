from __future__ import annotations

import re
from typing import Iterable, List


def normalize_text(text: str) -> str:
    text = text.replace("\n", " ")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def chunk_text(text: str, max_tokens: int = 180) -> List[str]:
    words = text.split()
    chunks: list[str] = []
    current: list[str] = []
    for word in words:
        current.append(word)
        if len(current) >= max_tokens:
            chunks.append(" ".join(current))
            current = []
    if current:
        chunks.append(" ".join(current))
    return chunks


def preprocess_documents(docs: Iterable[str]) -> list[str]:
    processed: list[str] = []
    for doc in docs:
        norm = normalize_text(doc)
        processed.extend(chunk_text(norm))
    return processed
