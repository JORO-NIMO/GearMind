# Obulamu

Obulamu is a high-safety medical information and triage assistant built with FastAPI, React, and OpenAI models.

## Backend

- Python / FastAPI / Uvicorn
- SQLite via SQLAlchemy
- Retrieval using BM25 (`rank-bm25`) over a local medical snippet corpus
- OpenAI `gpt-4o-mini` (default) and `gpt-4o` (for complex or high-risk triage)

### Running the backend locally

1. Create and fill a `.env` file based on `.env.example`.
2. Create a virtual environment and install dependencies:

   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```

3. Start the API:

   ```bash
   uvicorn app.main:app --reload
   ```

The API will be available at `http://localhost:8000`. OpenAPI docs are at `/docs`.

### Subscriptions and PayPal billing

- Users receive 10 free chat queries (`FREE_TRIAL_MESSAGES`).
- After the free trial, they must subscribe for $5/month to continue.
- PayPal is used for subscription billing. Configure the following environment variables in `.env`:
  - `PAYPAL_CLIENT_ID`
  - `PAYPAL_SECRET`
  - `PAYPAL_ENVIRONMENT` (`sandbox` or `live`)
  - `PAYPAL_PLAN_ID` (a PayPal Subscriptions plan for $5/month)
  - `PAYPAL_WEBHOOK_ID` (for `/webhook/paypal`)
  - `PAYPAL_RETURN_URL` and `PAYPAL_CANCEL_URL`

## Frontend

The frontend is a Vite + React + TailwindCSS PWA located in `frontend/`.

### Running the frontend locally

```bash
cd frontend
npm install
npm run dev
```

By default the app expects the backend at `http://localhost:8000`. You can change this via `VITE_API_BASE_URL` in `frontend/.env.local`.

## Deployment on Render

- `render.yaml` defines:
  - A Dockerized FastAPI backend (`obulamu-backend`)
  - A static frontend (`obulamu-frontend`) built from the Vite app

Set the `OPENAI_API_KEY` and `JWT_SECRET` environment variables in Render for the backend service.
