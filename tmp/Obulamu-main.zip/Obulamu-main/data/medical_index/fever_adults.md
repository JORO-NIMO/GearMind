In adults, a fever is often a sign that the body is fighting an infection. Guidance from services like NHS suggests seeking urgent medical advice if a fever is very high, does not improve after several days, or is accompanied by symptoms such as chest pain, difficulty breathing, severe headache, stiff neck, or a rash that does not fade when pressed.

