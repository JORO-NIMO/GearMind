Within the backend application, prefer clear, explicit dependencies and straightforward FastAPI patterns. Avoid metaprogramming or overly clever abstractions. Keep routes, services, and models small and easy to follow.

